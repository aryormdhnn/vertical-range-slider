function geseratas() {
    document.getElementById("box").classList.remove("ganti-warna-slide");
    var sidebar = document.getElementById("slide-button")
    var button = document.getElementById("button")
    if (sidebar.style.top === "0px"){
        sidebar.style.top = "140px";
        button.style.background = "#00ff00";
            

    }

    else{
        document.getElementById("box").classList.add("ganti-warna-slide");
        sidebar.style.top = "0px";
        button.style.background = "red";
        }  

    }

    /*
    function geserbawah(){
    document.getElementById("slide-button").classList.add("geserbawah");
    document.getElementById("slide-button").classList.add("ganti-warna-slide");
    document.getElementById("box").classList.add("gantiwarna");
}

function geseratas(){
    document.getElementById("slide-button").classList.remove("geserbawah");
    document.getElementById("slide-button").classList.remove("ganti-warna-slide");
    document.getElementById("box").classList.remove("gantiwarna");
}
*/